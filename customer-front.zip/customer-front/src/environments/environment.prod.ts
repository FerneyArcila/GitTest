export const environment = {
    production: true,
    API_ENDPOINT: 'http://localhost:8080', // endpoint para producción  
  };
 
