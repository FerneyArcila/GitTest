export * from './customerAPI.service';
import { CustomerAPIService } from './customerAPI.service';
export const APIS = [CustomerAPIService];
