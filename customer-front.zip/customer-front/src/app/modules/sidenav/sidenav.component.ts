import { Component } from '@angular/core';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css']
})
export class SidenavComponent {
  saveit(): void{
    window.open('https://digitalthinking.biz/es/cursos/', '_blank');
    }
}
