export const environment = {
    production: false,
    API_ENDPOINT: 'http://localhost:80',// endpoint para desarrollo
  };